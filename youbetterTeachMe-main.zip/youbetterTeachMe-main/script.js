const form = document.getElementById('chatForm');
const input = document.getElementById('userInput');
const chatBox = document.getElementById('chatBox');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const userText = input.value.trim();
  if (userText === '') return;

  addMessage(userText, 'user');

  // Basic Socratic-style response logic
  const response = generateSocraticReply(userText);
  setTimeout(() => {
    addMessage(response, 'mentor');
  }, 600);

  input.value = '';
});

function addMessage(text, type) {
  const msg = document.createElement('div');
  msg.classList.add('message', type);
  msg.textContent = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function generateSocraticReply(input) {
  const starters = [
    "Why do you think that is?",
    "What assumptions are you making?",
    "Can you see this from another perspective?",
    "What do you think the consequences of that would be?",
    "Is there a deeper principle behind that idea?",
    "How would you explain this to a child?"
  ];
  return starters[Math.floor(Math.random() * starters.length)];
}
