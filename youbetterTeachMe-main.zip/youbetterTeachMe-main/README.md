# TeachMe - AI Socratic Mentor 🌸

**TeachMe** is a fun and engaging web app that acts as a Socratic AI tutor for teens. It helps users learn all branches of **math** and **science** through guided questioning rather than giving direct answers. Built with ❤️ using HTML, CSS, JavaScript, and OpenAI GPT-4.

## 🎯 Features
- Covers all major science and math topics
- Socratic-style AI mentor
- Interactive, guided learning
- Cute bubblegum pink, lilac, and black theme
- Designed for curious teens

## 🚀 How to Use
1. Ask any science or math question in the chat.
2. The AI responds with guiding questions and hints.
3. Keep exploring, reflecting, and learning!

## 🛠️ Tech Stack
- HTML / CSS / JavaScript
- OpenAI GPT-4 API
# TeachMe
an AI socratic tutor for math and science
